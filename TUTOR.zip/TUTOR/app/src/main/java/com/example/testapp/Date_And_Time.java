package com.example.testapp;

public class Date_And_Time {

    int id;

    String date;
    String time;

    public Date_And_Time(String date, String time){
        this.date = date;
        this.time = time;
    }
    public Date_And_Time(int id, String date, String time){
        this.id = id;
        this.date = date;
        this.time = time;
    }
}
