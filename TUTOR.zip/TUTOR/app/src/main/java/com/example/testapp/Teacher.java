package com.example.testapp;

public class Teacher {

    int id;
    String name;
    String surname;
    String phone;

    public Teacher(String name,String surname, String phone){
        this.name = name;
        this.surname = surname;
        this.phone = phone;
    }
    public Teacher(int id,String name,String surname, String phone){
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.phone = phone;
    }
}
