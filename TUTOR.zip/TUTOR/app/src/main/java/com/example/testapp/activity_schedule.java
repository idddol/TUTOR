package com.example.testapp;

import static android.app.PendingIntent.getActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.Locale;

import android.content.Intent;/*
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;*/


public class activity_schedule extends AppCompatActivity {

    DBHelper dbHelper;
    CalendarView calendarView;
    Calendar calendar;

    ListView listViewS;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_schedule);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new DBHelper(this);

        calendarView = findViewById(R.id.calendarView);
        calendar = Calendar.getInstance();
        listViewS = findViewById((R.id.listViewS));

        setDate(calendarView);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int day) {
                ArrayList<String> itemsS = new ArrayList<>();

                String selected_date;
                if (month < 10) {
                    selected_date = day + "/0" + (month + 1) + "/" + Math.abs(year % 100);
                }
                else {
                    selected_date= day + "/" + (month + 1) + "/" + Math.abs(year % 100);
                }

                LinkedList<Student> list = dbHelper.GetAllStudents();
                LinkedList<Date_And_Time> list1 = dbHelper.GetAllDateAndTime();
                LinkedList<Time_To_Student> arr;
                String name = null,time = null;
                int clas = 0;
                arr = dbHelper.SearchDate(selected_date);

                if(arr != null){
                    for (Time_To_Student ts : arr) {
                        for(Student s : list){
                            if(s.id == Integer.parseInt(ts.student)) {
                                name = s.name;
                                clas = s.clas;
                            }
                        }
                        for(Date_And_Time d : list1){
                            if(d.id == Integer.parseInt(ts.time)) {
                                time = d.time;
                            }
                        }
                        itemsS.add("Время  " + time + ", Имя  " + name + ", Класс  " + clas);
                    }
                }

                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, itemsS);
                listViewS.setAdapter(adapter);
            }

            private Context getActivity() {
                return activity_schedule.this;
            }
        });
    }
    public void goBack(View v){
        Intent intent = new Intent(this,activity_menu.class);
        startActivity(intent);
    }

    public void setDate(CalendarView calendarViewF) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        long currentDateMillis = calendar.getTimeInMillis();
        calendarViewF.setDate(currentDateMillis);
    }

//    public  void getDate(){
//        ArrayList<String> itemsS = new ArrayList<>();
//
//        long date = calendarView.getDate();
//        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yy", Locale.getDefault());
//        calendar.setTimeInMillis(date);
//        String selected_date = simpleDateFormat.format(calendar.getTime());
//        //Toast.makeText(this, selected_date, Toast.LENGTH_SHORT).show();
//
//        LinkedList<Student> list = dbHelper.SearchDate(selected_date);
//        for (Student s : list) {
//            itemsS.add(s.id + ", " + s.name + ", " + s.clas + ", " + s.price + ", " + s.phone + ", " + s.date);
//        }
//        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, itemsS);
//        listViewS.setAdapter(adapter);
//    }


}


/*///////////////////////////

    <?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
        xmlns:app="http://schemas.android.com/apk/res-auto"
        xmlns:tools="http://schemas.android.com/tools"
        android:id="@+id/main"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:orientation="vertical"
        tools:context=".MainActivity">

<CalendarView
        android:id="@+id/calendarView"
                android:layout_width="match_parent"
                android:layout_height="wrap_content" />


<EditText
        android:id="@+id/editName"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:ems="10"
                app:layout_constraintStart_toStartOf="parent"
                app:layout_constraintTop_toTopOf="parent" />

<EditText
        android:id="@+id/editClass"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:ems="10"
                android:inputType="number"
                app:layout_constraintStart_toStartOf="parent"
                app:layout_constraintTop_toBottomOf="@+id/editName" />

<EditText
        android:id="@+id/editPrice"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:ems="10"
                android:inputType="number"
                app:layout_constraintStart_toStartOf="parent"
                app:layout_constraintTop_toBottomOf="@+id/editClass" />

<EditText
        android:id="@+id/editPhone"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:ems="10"
                app:layout_constraintStart_toStartOf="parent"
                app:layout_constraintTop_toBottomOf="@+id/editPrice" />

<Button
        android:id="@+id/buttonDel"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="DEL"
                app:layout_constraintBottom_toBottomOf="parent"
                app:layout_constraintStart_toStartOf="parent" />

<Button
        android:id="@+id/buttonAdd"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="ADD"
                app:layout_constraintBottom_toBottomOf="parent"
                app:layout_constraintStart_toEndOf="@+id/buttonDel" />

<Button
        android:id="@+id/buttonGet"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="GET"
                app:layout_constraintBottom_toBottomOf="parent"
                app:layout_constraintStart_toEndOf="@+id/buttonAdd" />

<TextView
        android:id="@+id/tvOut"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                app:layout_constraintStart_toStartOf="parent"
                app:layout_constraintTop_toBottomOf="@+id/editPhone" />

<Button
        android:id="@+id/buttonDelOne"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="DEL ONE"
                app:layout_constraintBottom_toTopOf="@+id/buttonDel"
                app:layout_constraintStart_toStartOf="parent" />

<Button
        android:id="@+id/buttonUpdate"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="UPDATE"
                app:layout_constraintBottom_toTopOf="@+id/buttonAdd"
                app:layout_constraintStart_toEndOf="@+id/buttonDelOne" />

<Button
        android:id="@+id/buttonSearch"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="SEARCH"
                app:layout_constraintBottom_toTopOf="@+id/buttonGet"
                app:layout_constraintStart_toEndOf="@+id/buttonUpdate" />

<EditText
        android:id="@+id/editNew"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:ems="10"
                android:inputType="text"
                app:layout_constraintBottom_toTopOf="@+id/buttonDelOne"
                app:layout_constraintStart_toStartOf="parent"
                tools:ignore="MissingConstraints" />



</LinearLayout>


        package com.example.testapp;

        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.CalendarView;
        import android.widget.EditText;
        import android.widget.TextView;
        import android.widget.Toast;

        import androidx.activity.EdgeToEdge;
        import androidx.annotation.NonNull;
        import androidx.appcompat.app.AppCompatActivity;
        import androidx.core.graphics.Insets;
        import androidx.core.view.ViewCompat;
        import androidx.core.view.WindowInsetsCompat;

        import java.text.SimpleDateFormat;
        import java.util.Calendar;
        import java.util.LinkedList;
        import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    DBHelper dbHelper;
    TextView tvOut;
    EditText ename, eclass, eprice, ephone, eNew;
    Button btnDel, btnAdd, btnGet,btnDelOne, btnUpdate, btnSearch;
    CalendarView calendarView;
    Calendar calendar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new DBHelper(this);

        tvOut = findViewById(R.id.tvOut);

        ename = findViewById(R.id.editName);
        eclass = findViewById(R.id.editClass);
        eprice = findViewById(R.id.editPrice);
        ephone = findViewById(R.id.editPhone);
        eNew = findViewById(R.id.editNew);

        btnDel = findViewById(R.id.buttonDel);
        btnAdd = findViewById(R.id.buttonAdd);
        btnGet = findViewById(R.id.buttonGet);
        btnDelOne = findViewById(R.id.buttonDelOne);
        btnUpdate = findViewById(R.id.buttonUpdate);
        btnSearch = findViewById(R.id.buttonSearch);

        calendarView = findViewById(R.id.calendarView);
        calendar = Calendar.getInstance();

        btnDel.setOnClickListener(this);
        btnAdd.setOnClickListener(this);
        btnGet.setOnClickListener(this);
        btnDelOne.setOnClickListener(this);
        btnUpdate.setOnClickListener(this);
        btnSearch.setOnClickListener(this);

        setDate(21, 12, 2023);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int day) {
                Toast.makeText(MainActivity.this, day + "/" + month + 1 + "/" + year, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onClick(View v) {
        LinkedList<Data> list = dbHelper.GetAll();

        String text = "";

        int viewId = v.getId();
        if (viewId == R.id.buttonDel) {
            dbHelper.DeleteAll();
        } else if (viewId == R.id.buttonAdd) {
            String name = ename.getText().toString();
            int clas = Integer.parseInt(eclass.getText().toString());
            int price = Integer.parseInt(eprice.getText().toString());
            String phone = ephone.getText().toString();
            Data data = new Data(name, clas, price, phone);
            dbHelper.AddOne(data);
        } else if (viewId == R.id.buttonGet) {
            list = dbHelper.GetAll();

            for (Data d : list) {
                text = text + d.name + " " + d.clas + " " + d.phone + " " + d.price + "\n";
            }

            tvOut.setText(text);
        }else if (viewId == R.id.buttonDelOne){
            dbHelper.DeleteOne(eNew.getText().toString());
        } else if(viewId == R.id.buttonUpdate){
            dbHelper.UpdateOne(eNew.getText().toString());
        } else if(viewId == R.id.buttonSearch){
            list = dbHelper.Search(eNew.getText().toString());
            for (Data d : list) {
                text = text + d.name + " " + d.clas + " " + d.phone + " " + d.price + "\n";
            }
            tvOut.setText(text);
        }
    }

    public void setDate(int day, int mouth, int year) {
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, mouth - 1);
        calendar.set(Calendar.DAY_OF_MONTH, day);
        long milli = calendar.getTimeInMillis();
        calendarView.setDate(milli);
    }

    public  void getDate(){
        long date = calendarView.getDate();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yy", Locale.getDefault());
        calendar.setTimeInMillis(date);
        String selected_date = simpleDateFormat.format(calendar.getTime());
        Toast.makeText(this, selected_date, Toast.LENGTH_SHORT).show();
    }*/
