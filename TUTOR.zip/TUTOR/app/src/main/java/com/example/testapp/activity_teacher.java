package com.example.testapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.LinkedList;

public class activity_teacher extends AppCompatActivity implements View.OnClickListener {
    DBHelper dbHelper;
    EditText ename, esurname, ephone;
    Button btnDel, btnAddTeacher, btnGet, btnAddStudentToTeacher, btnSearch;
    ListView listView;
    Spinner spStudents,spTeachers;
    LinkedList<Student> students = new LinkedList<>();
    LinkedList<Teacher> teachers = new LinkedList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_teacher);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new DBHelper(this);

        students = dbHelper.GetAllStudents();
        LinkedList<String> arr = new LinkedList<>();
        for(Student s : students){
            arr.add(s.name +  ", " + s.clas);
        }
        ArrayAdapter<String> studentArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arr);
        studentArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spStudents = (Spinner) findViewById(R.id.spinnerStudents);
        spStudents.setAdapter(studentArrayAdapter);

        teachers = dbHelper.GetAllTeachers();
        LinkedList<String> arr1 = new LinkedList<>();
        for(Teacher t : teachers){
            arr1.add(t.name + ", " + t.surname);
        }
        ArrayAdapter<String> teacherArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arr1);
        teacherArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spTeachers = (Spinner) findViewById(R.id.spinnerTeachers);
        spTeachers.setAdapter(teacherArrayAdapter);

        ename = findViewById(R.id.editName);
        esurname = findViewById(R.id.editSurname);
        ephone = findViewById(R.id.editPhone);

        btnDel = findViewById(R.id.buttonDel);
        btnAddTeacher = findViewById(R.id.buttonAdd);
        btnGet = findViewById(R.id.buttonGet);
        btnSearch = findViewById(R.id.buttonSearch);
        btnAddStudentToTeacher = findViewById(R.id.buttonAddStudentToTeacher);

        btnDel.setOnClickListener(this);
        btnAddTeacher.setOnClickListener(this);
        btnGet.setOnClickListener(this);
        btnSearch.setOnClickListener(this);
        btnAddStudentToTeacher.setOnClickListener(this);

        listView = findViewById(R.id.listView);
    }
    public void onClick(View v) {
        LinkedList<Teacher> list = dbHelper.GetAllTeachers();
        ArrayList<String> items = new ArrayList<>();

        int viewId = v.getId();
        if (viewId == R.id.buttonDel) {
            dbHelper.DeleteAllTeachers();
        } else if (viewId == R.id.buttonAdd) {
            String name = ename.getText().toString();
            String surname = esurname.getText().toString();
            String phone = ephone.getText().toString();
            Teacher teacher = new Teacher(name,surname,phone);
            dbHelper.AddTeacher(teacher);
            Toast.makeText(this, "Успешно!", Toast.LENGTH_SHORT).show();
        } else if (viewId == R.id.buttonGet) {
            list = dbHelper.GetAllTeachers();
            for (Teacher t : list) {
                items.add("Имя  " + t.name + ", Фамилия  " + t.surname + ", Телефон  " + t.phone);
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
            listView.setAdapter(adapter);
        }else if(viewId == R.id.buttonSearch){
            LinkedList<Student_To_Teacher> arr;
            LinkedList<Teacher> teach = dbHelper.GetAllTeachers();
            String temp = spTeachers.getSelectedItem().toString();
            String[] words = temp.split(" ");
            String name = words[0].replace(",","");
            String surname = words[1];
            int id_teacher = 0;
            for(Teacher t : teach){
                if(t.name.equals(name) && t.surname.equals(surname)){
                    id_teacher = t.id;
                    break;
                }
            }

            arr = dbHelper.SearchTeacher(id_teacher);
            LinkedList<Student> l = dbHelper.GetAllStudents();
            String name_s = null,phone = null;
            int clas = 0,price = 0;
            for (Student_To_Teacher s : arr) {
                for(Student stud : l){
                    if(stud.id == Integer.parseInt(s.student)){
                        name_s = stud.name;
                        clas = stud.clas;
                        price = stud.price;
                        phone = stud.phone;
                    }
                }
                items.add(name_s + ", " + clas + ", " + price + ", " + phone);
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
            listView.setAdapter(adapter);
        } else if(viewId == R.id.buttonAddStudentToTeacher) {
            int teacher = 0,student = 0;
            LinkedList<Student> as = dbHelper.GetAllStudents();
            LinkedList<Teacher> at = dbHelper.GetAllTeachers();

            String teachers = spTeachers.getSelectedItem().toString();
            String[] teach_arr = teachers.split(" ");
            String name_t = teach_arr[0].replace(",","");
            String surname = teach_arr[1];
            for(Teacher t : at){
                if(t.name.equals(name_t) && t.surname.equals(surname)){
                    teacher = t.id;
                }
            }

            String students = spStudents.getSelectedItem().toString();
            String[] stud_arr = students.split(" ");
            String name_s = stud_arr[0].replace(",","");
            int clas = Integer.parseInt(stud_arr[1]);
            for(Student s : as){
                if(s.name.equals(name_s) && s.clas == clas){
                    student = s.id;
                }
            }
            dbHelper.AddStudentToTeacher(teacher,student);
            Toast.makeText(this, "Успешно!", Toast.LENGTH_SHORT).show();
        }
    }
    public void goBack(View v){
        Intent intent = new Intent(this,activity_menu.class);
        startActivity(intent);
    }
}