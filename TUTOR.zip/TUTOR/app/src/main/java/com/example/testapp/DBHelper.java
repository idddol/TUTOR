package com.example.testapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.AndroidException;

import androidx.annotation.Nullable;

import java.util.LinkedList;

public class DBHelper extends SQLiteOpenHelper {
    private static final String STUDENTS = "STUDENTS";
    private static final String TEACHERS = "TEACHERS";
    private static final String STUDENTS_TO_TEACHERS = "STUDENTS_TO_TEACHERS";
    private static final String DATE_AND_TIME = "DATE_AND_TIME";
    private static final String TIME_TO_STUDENTS = "TIME_TO_STUDENTS";

    //---------------------------------------------------------------------------
    private static final String COLUMN_STUDENT_ID = "COLUMN_ID";
    private static final String COLUMN_STUDENT_NAME = "COLUMN_NAME";
    private static final String COLUMN_CLASS = "COLUMN_CLASS";
    private static final String COLUMN_PRICE = "COLUMN_PRICE";
    private static final String COLUMN_PHONE = "COLUMN_PHONE";
    private static final String COLUMN_DATE = "COLUMN_DATE";
    private static final String COLUMN_TEACHER_ID = "COLUMN_ID";
    private static final String COLUMN_TEACHER_NAME = "COLUMN_NAME";
    private static final String COLUMN_TEACHER = "COLUMN_TEACHER_ID";
    private static final String COLUMN_STUDENT = "COLUMN_STUDENT_ID";
    private static final String COLUMN_STUDENTS_TO_TEACHERS_ID = "COLUMN_ID";
    private static final String COLUMN_DATE_AND_TIME_ID = "COLUMN_ID";
    private static final String COLUMN_TIME = "COLUMN_TIME";
    private static final String COLUMN_TIME_TO_STUDENTS_ID = "COLUMN_ID";
    private static final String COLUMN_TIME_ID = "COLUMN_TIME_ID";
    private static final String COLUMN_TEACHER_SURNAME = "COLUMN_SURNAME";
    private static final String COLUMN_TEACHER_PHONE = "COLUMN_PHONE";


    public DBHelper(@Nullable Context context) {
        super(context, "example.db",null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + STUDENTS + " (" + COLUMN_STUDENT_ID + " INTEGER PRIMARY KEY, " + COLUMN_STUDENT_NAME + " TEXT, " + COLUMN_CLASS +
                " INTEGER, " + COLUMN_PRICE + " INTEGER, " +  COLUMN_PHONE + " TEXT);");
        db.execSQL("CREATE TABLE " + TEACHERS + " (" + COLUMN_TEACHER_ID + " INTEGER PRIMARY KEY, " + COLUMN_TEACHER_NAME + " TEXT, "
                + COLUMN_TEACHER_SURNAME + " TEXT, " + COLUMN_TEACHER_PHONE + " TEXT);");
        db.execSQL("CREATE TABLE " + STUDENTS_TO_TEACHERS + " (" + COLUMN_STUDENTS_TO_TEACHERS_ID + " INTEGER PRIMARY KEY, " + COLUMN_TEACHER + " INTEGER, " + COLUMN_STUDENT + " INTEGER);");
        db.execSQL("CREATE TABLE " + DATE_AND_TIME+ " (" + COLUMN_DATE_AND_TIME_ID+ " INTEGER PRIMARY KEY, " + COLUMN_DATE + " TEXT, " + COLUMN_TIME + " TEXT);");
        db.execSQL("CREATE TABLE " + TIME_TO_STUDENTS+ " (" + COLUMN_TIME_TO_STUDENTS_ID+ " INTEGER PRIMARY KEY, " + COLUMN_STUDENT + " INTEGER, " + COLUMN_TIME_ID + " INTEGER);");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + STUDENTS);

        onCreate(db);
    }

    public void DeleteAllStudents(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(STUDENTS, null, null);
        db.delete(TIME_TO_STUDENTS, null, null);
        db.delete(STUDENTS_TO_TEACHERS, null, null);
        db.close();
    }
    public void DeleteAllTeachers(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TEACHERS, null, null);
        db.delete(STUDENTS_TO_TEACHERS, null, null);
        db.close();
    }
    public void DeleteOneStudent(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(STUDENTS, COLUMN_STUDENT_ID +" = cast(? as integer)", new String[]{String.valueOf(id)});
        db.delete(TIME_TO_STUDENTS, COLUMN_STUDENT +" = cast(? as integer)", new String[]{String.valueOf(id)});
        db.delete(STUDENTS_TO_TEACHERS, COLUMN_STUDENT +" = cast(? as integer)", new String[]{String.valueOf(id)});
        db.close();
    }

    public void UpdateStudent(int id,String name, int clas, int price, String phone){
        LinkedList<Student> students = GetAllStudents();

        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("update STUDENTS set COLUMN_NAME = '" + name + "', COLUMN_CLASS = " + clas +"," +
                " COLUMN_PRICE = " + price + ", COLUMN_PHONE = '" + phone + "' where COLUMN_ID = " + id + ";");

        db.close();
    }

    public void AddStudent(Student student) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(COLUMN_STUDENT_NAME, student.name);
        cv.put(COLUMN_CLASS, student.clas);
        cv.put(COLUMN_PRICE, student.price);
        cv.put(COLUMN_PHONE, student.phone);

        db.insert(STUDENTS, null, cv);

        db.close();
    }
    public void AddTeacher(Teacher teacher) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(COLUMN_TEACHER_NAME, teacher.name);
        cv.put(COLUMN_TEACHER_SURNAME, teacher.surname);
        cv.put(COLUMN_TEACHER_PHONE, teacher.phone);

        db.insert(TEACHERS, null, cv);

        db.close();
    }

    public void AddStudentToTeacher(int id_teacher, int id_student) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(COLUMN_TEACHER, id_teacher);
        cv.put(COLUMN_STUDENT, id_student);

        db.insert(STUDENTS_TO_TEACHERS, null, cv);

        db.close();
    }
    public void AddDateAndTime(Date_And_Time dateAndTime) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(COLUMN_DATE, dateAndTime.date);
        cv.put(COLUMN_TIME, dateAndTime.time);

        db.insert(DATE_AND_TIME, null, cv);

        db.close();
    }
    public void AddTimeToStudent(int id_student, int id_time) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(COLUMN_STUDENT, id_student);
        cv.put(COLUMN_TIME_ID, id_time);

        db.insert(TIME_TO_STUDENTS, null, cv);

        db.close();
    }

    public LinkedList<Student> GetAllStudents() {
        LinkedList<Student> list = new LinkedList<>();
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(STUDENTS, null, null, null, null, null, COLUMN_STUDENT_NAME);

        if(cursor.moveToFirst()) {
            do {
                int id_id = cursor.getColumnIndex(COLUMN_STUDENT_ID);
                int id_n = cursor.getColumnIndex(COLUMN_STUDENT_NAME);
                int id_c = cursor.getColumnIndex(COLUMN_CLASS);
                int id_pr = cursor.getColumnIndex(COLUMN_PRICE);
                int id_ph = cursor.getColumnIndex(COLUMN_PHONE);

                Student student = new Student(cursor.getInt(id_id), cursor.getString(id_n), cursor.getInt(id_c), cursor.getInt(id_pr), cursor.getString(id_ph));
                list.add(student);
            } while (cursor.moveToNext());
        }

        db.close();
        return list;
    }
    public LinkedList<Teacher> GetAllTeachers() {
        LinkedList<Teacher> list = new LinkedList<>();
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(TEACHERS, null, null, null, null, null, COLUMN_TEACHER_NAME);

        if(cursor.moveToFirst()) {
            do {
                int id_id = cursor.getColumnIndex(COLUMN_TEACHER_ID);
                int id_n = cursor.getColumnIndex(COLUMN_TEACHER_NAME);
                int id_s = cursor.getColumnIndex(COLUMN_TEACHER_SURNAME);
                int id_ph = cursor.getColumnIndex(COLUMN_TEACHER_PHONE);

                Teacher teacher = new Teacher(cursor.getInt(id_id),cursor.getString(id_n),cursor.getString(id_s),cursor.getString(id_ph));
                list.add(teacher);
            } while (cursor.moveToNext());
        }

        db.close();
        return list;
    }
    public LinkedList<Date_And_Time> GetAllDateAndTime() {
        LinkedList<Date_And_Time> list = new LinkedList<>();
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(DATE_AND_TIME, null, null, null, null, null, null);

        if(cursor.moveToFirst()) {
            do {
                int id_id = cursor.getColumnIndex(COLUMN_DATE_AND_TIME_ID);
                int id_d = cursor.getColumnIndex(COLUMN_DATE);
                int id_t = cursor.getColumnIndex(COLUMN_TIME);

                Date_And_Time dateAndTime = new Date_And_Time(cursor.getInt(id_id),cursor.getString(id_d),cursor.getString(id_t));
                list.add(dateAndTime);
            } while (cursor.moveToNext());
        }

        db.close();
        return list;
    }

    public LinkedList<Student_To_Teacher> GetAllStudentToTeacher() {
        LinkedList<Student_To_Teacher> list = new LinkedList<>();
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(STUDENTS_TO_TEACHERS, null, null, null, null, null, null);

        if(cursor.moveToFirst()) {
            do {
                int id_id = cursor.getColumnIndex(COLUMN_STUDENTS_TO_TEACHERS_ID);
                int id_t = cursor.getColumnIndex(COLUMN_TEACHER);
                int id_s = cursor.getColumnIndex(COLUMN_STUDENT);

                Student_To_Teacher student_to_teacher = new Student_To_Teacher(cursor.getInt(id_id),cursor.getString(id_t),cursor.getString(id_s));
                list.add(student_to_teacher);
            } while (cursor.moveToNext());
        }

        db.close();
        return list;
    }
    public LinkedList<Time_To_Student> GetAllTimeToStudent() {
        LinkedList<Time_To_Student> list = new LinkedList<>();
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(TIME_TO_STUDENTS, null, null, null, null, null, null);

        if(cursor.moveToFirst()) {
            do {
                int id_id = cursor.getColumnIndex(COLUMN_TIME_TO_STUDENTS_ID);
                int id_s = cursor.getColumnIndex(COLUMN_STUDENT);
                int id_t = cursor.getColumnIndex(COLUMN_TIME_ID);

                Time_To_Student time_to_student = new Time_To_Student(cursor.getInt(id_id),cursor.getString(id_s),cursor.getString(id_t));
                list.add(time_to_student);
            } while (cursor.moveToNext());
        }

        db.close();
        return list;
    }

    public LinkedList<Student> Search(int id){
        LinkedList<Student> list = new LinkedList<>();
        SQLiteDatabase db = this.getWritableDatabase();
        //select * from STUDENTS where COLUMN_NAME like '{name}';
        Cursor cursor = db.rawQuery("select * from STUDENTS where COLUMN_ID like '" + id + "';",null);

        if(cursor.moveToFirst()) {
            do {
                int id_n = cursor.getColumnIndex(COLUMN_STUDENT_NAME);
                int id_c = cursor.getColumnIndex(COLUMN_CLASS);
                int id_pr = cursor.getColumnIndex(COLUMN_PRICE);
                int id_ph = cursor.getColumnIndex(COLUMN_PHONE);

                Student student = new Student(cursor.getString(id_n), cursor.getInt(id_c), cursor.getInt(id_pr), cursor.getString(id_ph));
                list.add(student);
            } while (cursor.moveToNext());
        }

        db.close();
        return list;
    }
    public LinkedList<Time_To_Student> SearchDate(String date){
        LinkedList<Time_To_Student> list = new LinkedList<>();
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("select *" +
                " from TIME_TO_STUDENTS ts inner join STUDENTS s on ts.COLUMN_STUDENT_ID = s.COLUMN_ID " +
                "inner join DATE_AND_TIME dt on ts.COLUMN_TIME_ID = dt.COLUMN_ID" +
                " where dt.COLUMN_DATE like '" + date+ "' order by dt.COLUMN_TIME asc;",null);

        if(cursor.moveToFirst()) {
            do {
                int id_id = cursor.getColumnIndex(COLUMN_TIME_TO_STUDENTS_ID);
                int id_st = cursor.getColumnIndex(COLUMN_STUDENT);
                int id_time= cursor.getColumnIndex(COLUMN_TIME_ID);

                Time_To_Student time_to_student = new Time_To_Student(cursor.getInt(id_id),cursor.getString(id_st),cursor.getString(id_time));
                list.add(time_to_student);
            } while (cursor.moveToNext());
        }

        db.close();
        return list;
    }

    public LinkedList<Student_To_Teacher> SearchTeacher(int id_teacher){
        LinkedList<Student_To_Teacher> list = new LinkedList<>();
        LinkedList<Teacher> teachers = GetAllTeachers();
        String name_teacher = null;
        for(Teacher t : teachers){
            if(t.id == id_teacher){
                name_teacher = t.name;
                break;
            }
        }
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select *" +
                " from STUDENTS_TO_TEACHERS st inner join TEACHERS t on st.COLUMN_TEACHER_ID = t.COLUMN_ID " +
                "inner join STUDENTS s on st.COLUMN_STUDENT_ID = s.COLUMN_ID" +
                " where t.COLUMN_NAME like '" + name_teacher + "';",null);


        if(cursor.moveToFirst()) {
            do {
                int id_id = cursor.getColumnIndex(COLUMN_STUDENTS_TO_TEACHERS_ID);
                int id_n = cursor.getColumnIndex(COLUMN_STUDENT);

                Student_To_Teacher student_to_teacher = new Student_To_Teacher(cursor.getInt(id_id),cursor.getString(id_n));
                list.add(student_to_teacher);
            } while (cursor.moveToNext());
        }

        db.close();
        return list;
    }
    public LinkedList<Time_To_Student> SearchTime(String name){
        LinkedList<Time_To_Student> list = new LinkedList<>();
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("select *" +
                " from TIME_TO_STUDENTS ts inner join STUDENTS s on ts.COLUMN_STUDENT_ID = s.COLUMN_ID " +
                "inner join DATE_AND_TIME dt on ts.COLUMN_TIME_ID = dt.COLUMN_ID" +
                " where s.COLUMN_NAME like '" + name + "'/* order by STUDENTS.COLUMN_NAME asc*/;",null);


        if(cursor.moveToFirst()) {
            do {
                int id_id = cursor.getColumnIndex(COLUMN_TIME_TO_STUDENTS_ID);
                int id_s = cursor.getColumnIndex(COLUMN_STUDENT);

                Time_To_Student time_to_student = new Time_To_Student(cursor.getInt(id_id),cursor.getString(id_s));
                list.add(time_to_student);
            } while (cursor.moveToNext());
        }


        db.close();
        return list;
    }
    public LinkedList<Time_To_Student> Finance(LinkedList<String> arr){
        LinkedList<Time_To_Student> list = new LinkedList<>();
        SQLiteDatabase db = this.getWritableDatabase();
        String date1 = arr.get(0);
        String date2 = arr.get(1);

        Cursor cursor = db.rawQuery("select *" +
                " from TIME_TO_STUDENTS ts inner join STUDENTS s on ts.COLUMN_STUDENT_ID = s.COLUMN_ID " +
                "inner join DATE_AND_TIME dt on ts.COLUMN_TIME_ID = dt.COLUMN_ID" + " WHERE dt.COLUMN_DATE >= '"+ date1 +
                "' AND dt.COLUMN_DATE <= '" + date2 + "';",null);


        if(cursor.moveToFirst()) {
            do {
                int id_id = cursor.getColumnIndex(COLUMN_TIME_TO_STUDENTS_ID);
                int id_s = cursor.getColumnIndex(COLUMN_STUDENT);

                Time_To_Student time_to_student = new Time_To_Student(cursor.getInt(id_id),cursor.getString(id_s));
                list.add(time_to_student);
            } while (cursor.moveToNext());
        }

        db.close();
        return list;
    }
}
