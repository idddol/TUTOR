package com.example.testapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedList;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class activity_student extends AppCompatActivity implements View.OnClickListener {

    DBHelper dbHelper;
    EditText ename, eclass, eprice, ephone;
    Button btnDel, btnAddStudent, btnGet,btnDelOne, btnSearch;

    ListView listView;
    LinkedList<Student> students = new LinkedList<>();
    Spinner spStudents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_student);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new DBHelper(this);

        students = dbHelper.GetAllStudents();
        LinkedList<String> arr = new LinkedList<>();
        for(Student s : students){
            arr.add(s.name +  ", " + s.clas);
        }
        ArrayAdapter<String> studentArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arr);
        studentArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spStudents = (Spinner) findViewById(R.id.spinnerStudents);

        spStudents.setAdapter(studentArrayAdapter);

        ename = findViewById(R.id.editName);
        eclass = findViewById(R.id.editClass);
        eprice = findViewById(R.id.editPrice);
        ephone = findViewById(R.id.editPhone);

        btnDel = findViewById(R.id.buttonDel);
        btnAddStudent = findViewById(R.id.buttonAdd);
        btnGet = findViewById(R.id.buttonGet);
        btnDelOne = findViewById(R.id.buttonDelOne);
        btnSearch = findViewById(R.id.buttonSearch);

        btnDel.setOnClickListener(this);
        btnAddStudent.setOnClickListener(this);
        btnGet.setOnClickListener(this);
        btnDelOne.setOnClickListener(this);
        btnSearch.setOnClickListener(this);

        listView = findViewById(R.id.listView);
    }

    @Override
    public void onClick(View v) {
        LinkedList<Student> list = dbHelper.GetAllStudents();
        ArrayList<String> items = new ArrayList<>();

        int viewId = v.getId();
        if (viewId == R.id.buttonDel) {
            dbHelper.DeleteAllStudents();
        } else if (viewId == R.id.buttonAdd) {
            String name = ename.getText().toString();
            int clas = Integer.parseInt(eclass.getText().toString());
            int price = Integer.parseInt(eprice.getText().toString());
            String phone = ephone.getText().toString();
            Student student = new Student(name, clas, price, phone);
            dbHelper.AddStudent(student);
            Toast.makeText(this, "Успешно!", Toast.LENGTH_SHORT).show();

            students = dbHelper.GetAllStudents();
            LinkedList<String> arr = new LinkedList<>();
            for(Student s : students){
                arr.add(s.name +  ", " + s.clas);
            }
            ArrayAdapter<String> studentArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arr);
            studentArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

            spStudents = (Spinner) findViewById(R.id.spinnerStudents);

            spStudents.setAdapter(studentArrayAdapter);
        } else if (viewId == R.id.buttonGet) {
            list = dbHelper.GetAllStudents();

            for (Student s : list) {
                items.add(s.name + "  " + s.clas + "  " + s.price + "  " + s.phone);
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
            listView.setAdapter(adapter);
        }else if (viewId == R.id.buttonDelOne){
            int id_student = 0;
            LinkedList<Student> list1 = dbHelper.GetAllStudents();
            String temp = spStudents.getSelectedItem().toString();
            String[] words = temp.split(" ");
            String name = words[0].replace(",","");
            int clas = Integer.parseInt(words[1]);
            for(Student s : list1){
                if(s.name.equals(name) && s.clas == clas){
                    id_student = s.id;
                }
            }
            dbHelper.DeleteOneStudent(id_student);
            Toast.makeText(this, "Успешно!", Toast.LENGTH_SHORT).show();
            students = dbHelper.GetAllStudents();
            LinkedList<String> arr = new LinkedList<>();
            for(Student s : students){
                arr.add(s.name +  ", " + s.clas);
            }
            ArrayAdapter<String> studentArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arr);
            studentArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

            spStudents = (Spinner) findViewById(R.id.spinnerStudents);

            spStudents.setAdapter(studentArrayAdapter);
        }else if (viewId == R.id.buttonSearch){
            int id_student = 0;
            LinkedList<Student> list1 = dbHelper.GetAllStudents();
            String temp = spStudents.getSelectedItem().toString();
            String[] words = temp.split(" ");
            String name = words[0].replace(",","");
            int clas = Integer.parseInt(words[1]);
            for(Student s : list1){
                if(s.name.equals(name) && s.clas == clas){
                    id_student = s.id;
                }
            }


            LinkedList<Student> array = dbHelper.Search(id_student);

            for (Student s : array) {
                items.add(s.name + ", " + s.clas + ", " + s.price + ", " + s.phone);
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
            listView.setAdapter(adapter);
        }

    }
    public void startNewActivity(View v){
        Intent intent = new Intent(this, activity_schedule.class);
        startActivity(intent);
    }
    public void goMenu(View v){
        Intent intent = new Intent(this,activity_menu.class);
        startActivity(intent);
    }
    public void goEditStudent(View v){
        Intent intent = new Intent(this,activity_edit.class);
        startActivity(intent);
    }
}