package com.example.testapp;

public class Time_To_Student {

    int id;
    String student;
    String time;
    public Time_To_Student(String student, String time){
        this.student = student;
        this.time = time;
    }
    public Time_To_Student(int id, String student){
        this.id = id;
        this.student = student;
    }
    public Time_To_Student(int id, String student, String time){
        this.id = id;
        this.student = student;
        this.time = time;
    }
}
