package com.example.testapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.LinkedList;

public class activity_edit extends AppCompatActivity implements View.OnClickListener {
    DBHelper dbHelper;
    EditText ename,eclas,eprice,ephone;
    Button btnSave;
    LinkedList<Student> students = new LinkedList<>();
    Spinner spStudents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new DBHelper(this);

        students = dbHelper.GetAllStudents();
        LinkedList<String> arr = new LinkedList<>();
        for(Student s : students){
            arr.add(s.name +  " " + s.clas);
        }
        ArrayAdapter<String> studentArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arr);
        studentArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spStudents = (Spinner) findViewById(R.id.SpinnerStudents);
        spStudents.setAdapter(studentArrayAdapter);

        ename = findViewById(R.id.editName);
        eclas = findViewById(R.id.editClas);
        eprice = findViewById(R.id.editPrice);
        ephone = findViewById(R.id.editPhone);

        btnSave = findViewById(R.id.ButtonSave);

        btnSave.setOnClickListener(this);

        spStudents.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent,
                                       View itemSelected, int selectedItemPosition, long selectedId) {

                LinkedList<Student> st = dbHelper.GetAllStudents();
                String temp = spStudents.getSelectedItem().toString();
                String[] words = temp.split(" ");
                String name = words[0];
                int clas = Integer.parseInt(words[1]);
                int id_student = 0;
                for(Student s : st){
                    if(s.name.equals(name) && s.clas == clas){
                        id_student = s.id;
                    }
                }
                LinkedList<Student> arr = dbHelper.Search(id_student);
                Student stud = arr.get(0);
                ename.setText(stud.name);
                eclas.setText(String.valueOf(stud.clas));
                eprice.setText(String.valueOf(stud.price));
                ephone.setText(stud.phone);
            }
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    public void goBack(View v){
        Intent intent = new Intent(this,activity_student.class);
        startActivity(intent);
    }
    public void goMenu(View v){
        Intent intent = new Intent(this,activity_menu.class);
        startActivity(intent);
    }

    @Override
    public void onClick(View v) {

        int viewId = v.getId();
        if(viewId == R.id.ButtonSave){
            String name = ename.getText().toString();
            int clas = Integer.parseInt(eclas.getText().toString());
            int price = Integer.parseInt(eprice.getText().toString());
            String phone = ephone.getText().toString();

            LinkedList<Student> st = dbHelper.GetAllStudents();
            String temp = spStudents.getSelectedItem().toString();
            String[] words = temp.split(" ");
            String name_ = words[0];
            int clas_ = Integer.parseInt(words[1]);
            int id_student = 0;
            for(Student s : st){
                if(s.name.equals(name_) && s.clas == clas_){
                    id_student = s.id;
                }
            }
            dbHelper.UpdateStudent(id_student,name,clas,price,phone);
            students = dbHelper.GetAllStudents();
            LinkedList<String> arr = new LinkedList<>();
            for(Student s : students){
                arr.add(s.name +  " " + s.clas);
            }
            ArrayAdapter<String> studentArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arr);
            studentArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spStudents = (Spinner) findViewById(R.id.SpinnerStudents);
            spStudents.setAdapter(studentArrayAdapter);
            Toast.makeText(this, "Успешно!", Toast.LENGTH_SHORT).show();
        }
    }
}