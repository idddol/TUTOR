package com.example.testapp;

public class Student_To_Teacher {

    int id;
    String teacher;
    String student;
    public Student_To_Teacher(int id,String student){
        this.id = id;
        this.student = student;
    }
    public Student_To_Teacher(int id, String teacher, String student){
        this.id = id;
        this.teacher = teacher;
        this.student = student;
    }
}
