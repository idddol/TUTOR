package com.example.testapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.Locale;

public class activity_finance extends AppCompatActivity{
    DBHelper dbHelper;
    CalendarView calendarViewF;
    Calendar calendar;
    TextView tvOut;
    ArrayList<String> twoDays = new ArrayList<>();
    LinkedList<Student> stu = new LinkedList<>();
    String temp;
    LinkedList<String> list = new LinkedList<>();
    int counterClick = 0;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_finance);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        calendarViewF = findViewById(R.id.calendarViewF);
        calendar = Calendar.getInstance();
        dbHelper = new DBHelper(this);
        tvOut = findViewById(R.id.textView2);


        setDate(calendarViewF);
        calendarViewF.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int day) {
                if (month < 10) {
                    temp = day + "/0" + (month + 1) + "/" + Math.abs(year % 100);
                }
                else {
                    temp = day + "/" + (month + 1) + "/" + Math.abs(year % 100);
                }
                twoDays.add(temp);
                counterClick+=1;
                if(counterClick == 2){
                    int sum = 0;
                    list.add(twoDays.get(twoDays.size() - 2));
                    list.add(twoDays.get(twoDays.size() - 1));
                    LinkedList<Time_To_Student> list1 = dbHelper.Finance(list);
                    LinkedList<Student> list2 = dbHelper.GetAllStudents();

                    for(Time_To_Student ts : list1){
                        for(Student s : list2){
                            if(Integer.parseInt(ts.student) == s.id){
                                sum+=s.price;
                            }
                        }
                    }
                    String date1 = twoDays.get(twoDays.size() - 2);
                    String date2 = twoDays.get(twoDays.size() - 1);
                    tvOut.setText(String.valueOf(date1 + "—" + date2 + " \nСумма " + sum));

                    list.clear();
                    counterClick = 0;
                }

            }
        });


    }
    public void setDate(CalendarView calendarViewF) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        long currentDateMillis = calendar.getTimeInMillis();
        calendarViewF.setDate(currentDateMillis);
    }
    public void goMenu(View v){
        Intent intent = new Intent(this,activity_menu.class);
        startActivity(intent);
    }

}
