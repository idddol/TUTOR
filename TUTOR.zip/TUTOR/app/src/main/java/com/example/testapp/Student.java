package com.example.testapp;


public class Student {
    int id;
    String name;
    int clas;
    int price;
    String phone;


    public Student(String name, int clas, int price, String phone) {
        this.name = name;
        this.clas = clas;
        this.price = price;
        this.phone = phone;
    }
    public Student(int id,String name, int clas, int price, String phone){
        this.id = id;
        this.name = name;
        this.clas = clas;
        this.price = price;
        this.phone = phone;
    }
//    public Student(int id,String name, int clas, int price, String phone, String date){
//        this.id = id;
//        this.name = name;
//        this.clas = clas;
//        this.price = price;
//        this.phone = phone;
//        this.date = date;
//    }
}

 //       /data/data/com.example.testapp/databases/example.db