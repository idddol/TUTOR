package com.example.testapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.Locale;

import android.content.Intent;/*
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;*/

public class activity_lesson extends AppCompatActivity implements View.OnClickListener{

    DBHelper dbHelper;
    EditText edate, etime;
    Button btnAdd;
    LinkedList<Student> list = new LinkedList<>();
    Spinner spStudents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_lesson);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new DBHelper(this);
        list = dbHelper.GetAllStudents();
        LinkedList<String> arr = new LinkedList<>();
        for(Student s : list){
            arr.add(s.name +  ", " + s.clas);
        }
        ArrayAdapter<String> studentArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arr);
        studentArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spStudents = (Spinner) findViewById(R.id.spStudents);

        spStudents.setAdapter(studentArrayAdapter);


        edate = findViewById(R.id.editDate);
        etime = findViewById(R.id.editTime);

        btnAdd = findViewById(R.id.buttonAddTime);

        btnAdd.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {
        LinkedList<Date_And_Time> list;
        LinkedList<Student> list1;
        int counter = 0;

        int viewId = v.getId();
        if(viewId == R.id.buttonAddTime){
            String date = edate.getText().toString();
            String time = etime.getText().toString();
            list = dbHelper.GetAllDateAndTime();
            for(Date_And_Time d : list){
                if(d.date.equals(date) && d.time.equals(time)){
                    Toast.makeText(activity_lesson.this, date + " " + time + " Занято!" , Toast.LENGTH_SHORT).show();
                    counter+=1;
                }
            }
            if(counter == 0){
                Date_And_Time dateAndTime = new Date_And_Time(date,time);
                dbHelper.AddDateAndTime(dateAndTime);

                String temp = spStudents.getSelectedItem().toString();
                String[] words = temp.split(" ");
                String name = words[0].replace(",","");
                int clas = Integer.parseInt(words[1]);

                list = dbHelper.GetAllDateAndTime();
                list1 = dbHelper.GetAllStudents();
                int id_time,id_student;
                for(Date_And_Time d : list){
                    if(d.date.equals(date) && d.time.equals(time)){
                        id_time = d.id;
                        for(Student s : list1){
                            if(s.name.equals(name) && s.clas == clas){
                                id_student = s.id;
                                dbHelper.AddTimeToStudent(id_student,id_time);
                            }
                        }
                    }
                }
            }
            Toast.makeText(this, "Успешно!", Toast.LENGTH_SHORT).show();
        }
    }
    public void goMenu(View v){
        Intent intent = new Intent(this,activity_menu.class);
        startActivity(intent);
    }
}